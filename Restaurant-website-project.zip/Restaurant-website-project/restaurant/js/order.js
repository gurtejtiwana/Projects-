//const foodRating = {
//    ogbono: 1,
//    egusi: 2,
//    bitterleaf: 1,
//    oha: 2,
//    native: 4,
//    okro: 0,
//    vegetable: 0,
//    okazi: 1
//}
//const totalStar = 5;
//
//// run rating when DOM loads
//
//document.addEventListener('DOMContentLoaded', getUserRatings);
//
////Get ratings
//function getUserRatings() {
//    for (let rating in foodRating) {
//        //get percentage
//        const ratingPercentage = (foodRating[rating] / totalStar) * 100;
//        
//        const ratingPercentageRoundUp = `${Math.round(ratingPercentage / 10) * 10}%`;
//        
//        document.querySelectorAll(`.${rating} .food-rating-star`).style.width = ratingPercentageRoundUp;
//
//    }
//}
//
//
