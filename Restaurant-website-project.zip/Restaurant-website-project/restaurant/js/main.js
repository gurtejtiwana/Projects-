//    side navigation  bar for mobile
function openNav() {
    document.getElementById('sideNav').style.width = '200px';
    document.getElementById('main').style.marginLeft = '200px';
}

function closeBtn() {
    document.getElementById('sideNav').style.width = '0';
    document.getElementById('main').style.marginLeft = '0';
}
//side nav bar ends here







//this is for the image slide animations 
// Detect request animation frame
var scroll = window.requestAnimationFrame ||
    // IE Fallback
    function (callback) {
        window.setTimeout(callback, 1000 / 60)
    };
var elementsToShow = document.querySelectorAll('.show-on-scroll');

function loop() {

    elementsToShow.forEach(function (element) {
        if (isElementInViewport(element)) {
            element.classList.add('is-visible');
        } else {
            element.classList.remove('is-visible');
        }
    });

    scroll(loop);
}

// Call the loop for the first time
loop();

function isElementInViewport(el) {
    // special bonus for those using jQuery
    if (typeof jQuery === "function" && el instanceof jQuery) {
        el = el[0];
    }
    var rect = el.getBoundingClientRect();
    return (
        (rect.top <= 0 &&
            rect.bottom >= 0) ||
        (rect.bottom >= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.top <= (window.innerHeight || document.documentElement.clientHeight)) ||
        (rect.top >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight))
    );
}
//image slide animation ends here





// this is for the to top rotating arrow button
var scrolling = document.getElementById('top')
window.addEventListener("scroll", function () {
    scrolling.style.transform = "rotate(" + window.pageYOffset + "deg)";
});
// to top arrow button ends here


//   scroll animation
$('.nav-menu a, .toggle-nav-menu a, #top, .order-btn').on('click', function (e) {
    if (this.hash !== '') {
        $('html, body').animate({
            scrollTop: $(this.hash).offset().top
        }, 700);
    };
});
